'''
Created by Joshua Godwin
Backend api for ai fishbone diagram creation tool
Ishikawa diagram, also known as a Fishbone or cause and effect diagram is a diagram that shows the causes of a certain event.
This tool allows users to create a fishbone diagram by inputting the main problem and getting Ai suggestions and help in determinging causes of the problem. Manual causes can be added and the diagram will update and generate new suggestions based on entries.
'''

'''
Architecture brainstorm:
Frontend asks user to input the main problem they have.
Frontend sends the main problem to the backend.
Backend builds a custom prompt with instructions to get main types of causes. sends to frontend.
Frontend displays categories and asks user if they wish to make any changes to categories
After any changes user continues and let's backend know to continue
Backend builds custom prompt for each category and builds causes based on problem and category.
Backend checks for duplicates causes between various categories, uses Ai to remove them.
Backend reviews total categories, causes, and problem and makes any additional changes to causes.
Backend sends list of causes/categories to frontend.
Frontend displays list of causes and categories to user and allows modification.
Once user finished they can continue.
Backend asks series of questions to get to go from qualitative to quantative data.
Something like which category do you believe is most likely to be the problem? and continues for each cause, subcause, etc. until it gets to a point where it asks "can this be measured?"
If yes, it asks how it can be measured and what the measurement is.
If no, ask for further information on the cause until can reach a measurable cause.
Ask for directionality in the measurements, if you change x what happens to y?
Once diagram finished provides action plan for user to take to solve the problem starting at most probable causes first.


'''
