from enum import Enum
import os
GEMENI_API_KEY = os.getenv('GEMENI_API_KEY')
import pathlib
import textwrap
import google-generativeai as gemeni


'''
Takes a string problem and returns a list of messages formatted for gemeni api messages body
'''
def build_cat_from_prob_prompt(problem):
    return [
        {
            "role": "system",
            "content": "You are a tool used for creating fishbone diagrams, also known as Ishikawa diagram."
        },
        {
            "role": "user",
            "content": "Given the following problem statement:" + problem + "get a list of categories that could be causes. For example for an engineering problem you would return categories like: materials, methods, machines, manpower, measurement, and environment."
        }
    ]

test_func = FunctionDeclaration(

)


class PromptType(Enum):
    CATEGORIES_FROM_PROBLEM = 1,
    FIRST_LAYER_CAUSES_FROM_CATEGORY = 2,
